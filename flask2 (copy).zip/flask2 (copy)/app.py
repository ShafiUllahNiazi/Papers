# import the Flask class from the flask module
from flask import Flask, render_template, redirect, url_for, request,session, flash, g
# from  flask.ext.sqlalchemy import SQLAlchemy
from flask_sqlalchemy import SQLAlchemy
from functools import wraps
# from models import User

# create the application object
app = Flask(__name__)
app.secret_key = "my precious"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.sqlite3'

#create the sqlalchemy object
db = SQLAlchemy(app)
print("ddddddddddddddd")
print(db)


class User(db.Model):

    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String, unique = True, nullable=False)
    email = db.Column(db.String, unique = True, nullable=False)
    password = db.Column(db.String)


    def __init__(self, name, email, password):
        self.name = name
        self.email = email
        self.password = password



    def __repr__(self):
        return '<name - {}>'.format(self.name)
db.create_all()



#login required decorator
def login_required(f):
    @wraps(f)
    def wrap(*args, ** kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash("You need to login first")
            return redirect(url_for('login'))
    return wrap

# use decorators to link the function to a url
@app.route('/')
@login_required
def home():
    return render_template('index.html')

@app.route('/welcome')
def welcome():
    return render_template('welcome.html')  # render a template

# Route for handling the login page logic
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        registered_user = User.query.filter_by(name=username, password=password).first()
        if registered_user is None:
            flash('Username or Password is invalid', 'error')
            return redirect(url_for('login'))
        else:
            session['logged_in'] = True
            flash("you were  just logged in")
            return redirect(url_for('home'))
    return render_template('login.html', error=error)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    error = None
    if request.method == 'POST':
        if request.form['username'] == '' or request.form['password'] == '' or request.form['email'] == '':
            error = 'Invalid Credentials. Please try again.'
        else:
            a = User(request.form['username'],request.form['email'],request.form['password'])
            a = db.session.add(a)
            db.session.commit()
            # print(User.query.all())

            # session['logged_in'] = True
            flash("you were  just sign up")
            return redirect(url_for('home'))
    return render_template('sign_up.html')




@app.route('/logout')
@login_required
def logout():
    session.pop('logged_in',None)
    flash("you were  just logged out")
    return redirect(url_for('login'))

# start the server with the 'run()' method
if __name__ == '__main__':
    app.run(debug=True)