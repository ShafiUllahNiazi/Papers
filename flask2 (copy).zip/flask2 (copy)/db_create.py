from app import db
from models import BlogPost

#create database and ab tables

db.create_all()